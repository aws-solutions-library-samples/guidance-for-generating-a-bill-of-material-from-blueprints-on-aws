# License Scan Report

**Project:** Guidance for Generating a Bill of Materials from Blueprints on AWS  
**Scan Date:** 2026-05-20  
**Project License:** Apache-2.0

---

## Summary

| Category | Count | Status |
|----------|-------|--------|
| Permissive (MIT, Apache-2.0, BSD, ISC) | 53 | ✅ No issues |
| Weak Copyleft (LGPL, MPL) | 0 | ✅ None found |
| Strong Copyleft (AGPL, GPL) | 1 | ⚠️ Requires review |
| Unknown / Not Found | 0 | ✅ All verified |

**Overall:** 1 dependency requires attention — PyMuPDF (AGPL-3.0).

---

## ⚠️ Flagged Dependencies

### PyMuPDF (pymupdf) — AGPL-3.0 / Artifex Commercial

| Field | Value |
|-------|-------|
| Package | pymupdf |
| Version | 1.25.4 |
| License | GNU Affero GPL 3.0 OR Artifex Commercial License |
| Used In | `patterns/blueprint-analyzer/requirements.txt` |
| Purpose | PDF rendering — splits blueprint PDFs into page images (150 DPI PNG) |
| Manifest | `patterns/blueprint-analyzer/requirements.txt:4` |

**Risk:** AGPL-3.0 requires that any software that interacts with AGPL-licensed code over a network must also be open-sourced under AGPL. Since this Guidance is published as open-source (Apache-2.0), the AGPL requirement is satisfied — users receive the full source code.

**Recommendation:** 
- For this open-source Guidance: **Acceptable** — the source code is publicly available, satisfying AGPL requirements.
- For customers deploying commercially: They should either (a) keep their deployment open-source, (b) obtain an Artifex Commercial License, or (c) replace PyMuPDF with an alternative like `pdf2image` (MIT) + Poppler.
- Document this in the README's "Additional Considerations" section.

---

## Frontend Dependencies (Node.js)

All 44 direct dependencies use permissive licenses.

| Package | Version | License | Verified |
|---------|---------|---------|----------|
| @eslint/eslintrc | ^3 | MIT | ✅ Registry |
| @hpcc-js/wasm-graphviz | ^1.21.5 | Apache-2.0 | ✅ Registry |
| @radix-ui/react-alert-dialog | ^1.1.15 | MIT | ✅ Registry |
| @radix-ui/react-dialog | ^1.1.15 | MIT | ✅ Registry |
| @radix-ui/react-progress | ^1.1.7 | MIT | ✅ Registry |
| @radix-ui/react-select | ^2.2.5 | MIT | ✅ Registry |
| @radix-ui/react-slot | ^1.2.4 | MIT | ✅ Registry |
| @shadcn/ui | ^0.0.4 | MIT | ✅ Registry |
| @tailwindcss/postcss | ^4 | MIT | ✅ Registry |
| @testing-library/jest-dom | ^6.1.5 | MIT | ✅ Registry |
| @testing-library/react | ^16.0.0 | MIT | ✅ Registry |
| @testing-library/user-event | ^14.5.1 | MIT | ✅ Registry |
| @types/node | ^25.0.3 | MIT | ✅ Registry |
| @types/react | ^19 | MIT | ✅ Registry |
| @types/react-dom | ^19 | MIT | ✅ Registry |
| @types/react-syntax-highlighter | ^15.5.13 | MIT | ✅ Registry |
| @typescript-eslint/eslint-plugin | ^8.55.0 | MIT | ✅ Registry |
| @typescript-eslint/parser | ^8.55.0 | MIT | ✅ Registry |
| @vitejs/plugin-react | ^4.2.0 | MIT | ✅ Registry |
| aws-amplify | ^6.16.2 | Apache-2.0 | ✅ Registry |
| class-variance-authority | ^0.7.1 | Apache-2.0 | ✅ Registry |
| clsx | ^2.1.1 | MIT | ✅ Registry |
| eslint | ^9.39.2 | MIT | ✅ Registry |
| fast-check | ^4.5.3 | MIT | ✅ Registry |
| jsdom | ^23.0.1 | MIT | ✅ Registry |
| lucide-react | ^0.562.0 | ISC | ✅ Registry |
| prettier | ^3.8.1 | MIT | ✅ Registry |
| radix-ui | ^1.4.3 | MIT | ✅ Registry |
| react | ^19.2.1 | MIT | ✅ Registry |
| react-dom | ^19.2.1 | MIT | ✅ Registry |
| react-dropzone | ^14.3.8 | MIT | ✅ Registry |
| react-markdown | ^10.1.0 | MIT | ✅ Registry |
| react-oidc-context | ^3.3.0 | MIT | ✅ Registry |
| react-router-dom | ^6.21.0 | MIT | ✅ Registry |
| react-spinners | ^0.17.0 | MIT | ✅ Registry |
| react-syntax-highlighter | ^16.1.0 | MIT | ✅ Registry |
| remark-gfm | ^4.0.1 | MIT | ✅ Registry |
| shadcn | ^3.0.0 | MIT | ✅ Registry |
| tailwind-merge | ^3.2.0 | MIT | ✅ Registry |
| tailwindcss | ^4 | MIT | ✅ Registry |
| tw-animate-css | ^1.2.9 | MIT | ✅ Registry |
| typescript | ^5 | Apache-2.0 | ✅ Registry |
| vite | ^7.3.2 | MIT | ✅ Registry |
| vitest | ^4.0.18 | MIT | ✅ Registry |

---

## Backend Dependencies (Python)

| Package | Version | License | Verified | Notes |
|---------|---------|---------|----------|-------|
| strands-agents | 1.32.0 | Apache-2.0 | ✅ PyPI | AWS Strands SDK |
| bedrock-agentcore | 1.4.7 | Apache-2.0 | ✅ PyPI | AWS AgentCore SDK |
| PyJWT | 2.12.1 | MIT | ✅ PyPI | JWT token handling |
| **pymupdf** | **1.25.4** | **AGPL-3.0 / Commercial** | ⚠️ PyPI | **See flagged section above** |
| Pillow | 11.2.1 | HPND (MIT-like) | ✅ PyPI | Image processing |
| boto3 | >=1.34.0 | Apache-2.0 | ✅ PyPI | AWS SDK |

---

## Infrastructure Dependencies (CDK - Node.js)

| Package | License | Notes |
|---------|---------|-------|
| aws-cdk-lib | Apache-2.0 | AWS CDK core |
| @aws-cdk/aws-bedrock-agentcore-alpha | Apache-2.0 | AgentCore L2 constructs |
| @aws-cdk/aws-amplify-alpha | Apache-2.0 | Amplify L2 constructs |
| @aws-cdk/aws-lambda-python-alpha | Apache-2.0 | Python Lambda bundling |
| constructs | Apache-2.0 | CDK constructs library |

---

## Project Root Dependencies (Python)

| Package | Version | License | Verified |
|---------|---------|---------|----------|
| boto3 | >=1.34.0 | Apache-2.0 | ✅ PyPI |
| requests | >=2.31.0 | Apache-2.0 | ✅ PyPI |
| PyYAML | >=6.0.1 | MIT | ✅ PyPI |
| colorama | >=0.4.6 | BSD-3-Clause | ✅ PyPI |

---

## License Compatibility Matrix

| License | Compatible with Apache-2.0? | Action Required |
|---------|----------------------------|-----------------|
| MIT | ✅ Yes | None |
| Apache-2.0 | ✅ Yes | None |
| ISC | ✅ Yes | None |
| BSD-3-Clause | ✅ Yes | None |
| HPND | ✅ Yes | None |
| AGPL-3.0 | ⚠️ Conditional | Source must be available (satisfied for open-source Guidance) |

---

## Recommendations

1. **Document PyMuPDF's AGPL license** in the README's "Additional Considerations" section, noting that commercial deployments may need an Artifex Commercial License or an alternative library.
2. All other dependencies are fully compatible with the project's Apache-2.0 license.
3. No action required for the 53 permissive-licensed dependencies.

---

*Licenses verified against npm registry (node_modules/*/package.json) and PyPI (pypi.org/pypi/*/json) on 2026-05-20.*
