# Threat Model — Guidance for Generating a Bill of Materials from Blueprints on AWS

## 1. What are we building?

**Blueprint Analyzer** is an AI-powered construction blueprint analysis pipeline that extracts material takeoffs, door/window schedules, wall assemblies, and project summaries from architectural PDF drawings. It uses Amazon Bedrock with Claude vision capabilities to read blueprint pages and produce structured, deterministic JSON output.

### Technical Components

| Component | Service | Description |
|-----------|---------|-------------|
| Frontend | AWS Amplify Hosting | React 19 SPA with TypeScript, authenticated via Cognito OIDC |
| Authentication | Amazon Cognito | User Pool with OAuth2 Authorization Code flow (users) and Client Credentials flow (M2M) |
| Blueprint API | Amazon API Gateway + AWS Lambda | REST API for PDF upload (presigned URLs), job management, and result retrieval |
| Agent Runtime | Amazon Bedrock AgentCore | Docker container running the multi-agent analysis pipeline (Strands SDK) |
| Vision Analysis | Amazon Bedrock (Claude Opus) | Analyzes blueprint page images to extract structural data |
| Text Processing | Amazon Bedrock (Claude Sonnet) | Material consolidation, project summary, audit, remediation, and chat |
| Agent Gateway | Amazon Bedrock AgentCore Gateway | MCP protocol gateway with JWT authentication for tool invocation |
| PDF/Result Storage | Amazon S3 | Stores uploaded PDFs, page images, and analysis results (JSON + MD) |
| Job Metadata | Amazon DynamoDB | Tracks job status, progress, and user ownership |
| Feedback Storage | Amazon DynamoDB | Stores user feedback on agent responses |
| Configuration | AWS SSM Parameter Store | Runtime configuration (ARNs, URLs, credentials) |
| Secrets | AWS Secrets Manager | Machine client secret for M2M OAuth2 authentication |
| Container Registry | Amazon ECR | Stores the AgentCore Runtime Docker image |
| Logging | Amazon CloudWatch Logs | Lambda function logs and API Gateway access logs |
| Infrastructure | AWS CloudFormation (CDK) | All resources deployed via AWS CDK |
| IAM | AWS IAM | Roles and policies for all service interactions |

### Data Flows

1. **User → Frontend → Cognito**: User authenticates via OAuth2 Authorization Code flow
2. **Frontend → API Gateway → Lambda → S3**: PDF uploaded via presigned URL
3. **Frontend → AgentCore Runtime**: Analysis invoked with JWT token, streams SSE progress events
4. **AgentCore Runtime → S3**: Downloads PDF, uploads page images and analysis results
5. **AgentCore Runtime → DynamoDB**: Creates/updates job status records
6. **AgentCore Runtime → Bedrock**: Invokes Claude Opus (vision) and Sonnet (text) models
7. **AgentCore Runtime → AgentCore Gateway**: Tool invocations via MCP protocol with M2M OAuth2
8. **Frontend → API Gateway → Lambda → S3**: Retrieves results via presigned URLs

---

## 2. What can go wrong?

### Threat Assessment (STRIDE)

| # | Threat | STRIDE Category | Severity | Likelihood | Description |
|---|--------|----------------|----------|------------|-------------|
| T1 | Unauthorized API access | Spoofing | High | Low | Attacker obtains or forges JWT token to access API endpoints |
| T2 | Cross-user data access | Elevation of Privilege | High | Low | Authenticated user accesses another user's jobs or results |
| T3 | Malicious PDF upload | Tampering | Medium | Medium | Crafted PDF exploits PDF parsing library vulnerabilities |
| T4 | Prompt injection via PDF | Tampering | Medium | Medium | Blueprint content contains text that manipulates agent behavior |
| T5 | S3 bucket data exposure | Information Disclosure | High | Low | Misconfigured bucket policy exposes uploaded blueprints |
| T6 | Presigned URL abuse | Information Disclosure | Medium | Low | Presigned URLs shared or intercepted to access private data |
| T7 | Agent hallucination | Information Disclosure | Low | Medium | Agent produces inaccurate material quantities or specifications |
| T8 | Denial of service via large PDFs | Denial of Service | Medium | Medium | Extremely large PDFs exhaust AgentCore Runtime resources |
| T9 | Secret exposure in logs | Information Disclosure | High | Low | Credentials or tokens logged to CloudWatch |
| T10 | Dependency vulnerabilities | Tampering | Medium | Medium | Known CVEs in npm/pip packages exploited |
| T11 | M2M token theft | Spoofing | High | Low | Machine client credentials compromised, allowing gateway access |
| T12 | Unencrypted data at rest | Information Disclosure | Medium | Low | Blueprint data stored without encryption |
| T13 | API throttling bypass | Denial of Service | Medium | Low | Attacker overwhelms API Gateway beyond throttle limits |
| T14 | Model output manipulation | Repudiation | Low | Low | No audit trail of what the model produced vs. what was stored |

---

## 3. What can we do about it?

### Access Control

| Control | Evidence | Threats Mitigated |
|---------|----------|-------------------|
| Cognito JWT validation on all API endpoints | `backend-stack.ts`: `CognitoUserPoolsAuthorizer` on all methods | T1 |
| AgentCore Runtime JWT authorizer | `backend-stack.ts`: `authorizerConfiguration` with Cognito OIDC discovery URL | T1 |
| Self-signup disabled | `cognito-stack.ts:28`: `selfSignUpEnabled: false` | T1 |
| Strong password policy | `cognito-stack.ts:35-40`: minLength 8, requireUppercase, requireDigits, requireSymbols | T1 |
| Ownership-scoped job deletion | `lambdas/blueprint-api/index.py:_delete_job()`: verifies `userId` matches before delete | T2 |
| User-scoped job queries | `lambdas/blueprint-api/index.py:_list_jobs()`: queries by authenticated user's `sub` claim | T2 |
| Prevent user existence errors | `cognito-stack.ts:72`: `preventUserExistenceErrors: true` | T1 |

### Data Protection

| Control | Evidence | Threats Mitigated |
|---------|----------|-------------------|
| S3 BlockPublicAccess.BLOCK_ALL | `backend-stack.ts`: BlueprintBucket, StagingBucket, AccessLogsBucket | T5 |
| S3 SSE encryption (S3_MANAGED) | `backend-stack.ts`: `encryption: s3.BucketEncryption.S3_MANAGED` | T12 |
| DynamoDB AWS-managed encryption | `backend-stack.ts`: `encryption: dynamodb.TableEncryption.AWS_MANAGED` | T12 |
| Presigned URLs expire in 1 hour | `storage.py:generate_presigned_url()`: `ExpiresIn=3600` | T6 |
| Upload presigned URLs expire in 15 min | `lambdas/blueprint-api/index.py`: `ExpiresIn=900` | T6 |
| SSL enforcement on staging bucket | `amplify-hosting-stack.ts`: Deny policy on `aws:SecureTransport=false` | T5, T12 |
| S3 lifecycle rules (30-day expiry) | `backend-stack.ts`: `expiration: cdk.Duration.days(30)` on uploads/ | T5 |
| DynamoDB point-in-time recovery | `backend-stack.ts`: `pointInTimeRecoveryEnabled: true` | T12 |

### Infrastructure Security

| Control | Evidence | Threats Mitigated |
|---------|----------|-------------------|
| Least-privilege IAM roles | `backend-stack.ts`: All policies scoped to specific ARNs, no `Resource: *` except Bedrock models | T11 |
| Secrets in Secrets Manager (not env vars) | `backend-stack.ts`: `machineClientSecret` in Secrets Manager | T9, T11 |
| No hardcoded secrets in code | ASH detect-secrets scan: 0 findings | T9 |
| API Gateway throttling | `backend-stack.ts`: `throttlingRateLimit: 100, throttlingBurstLimit: 200` | T13 |
| API Gateway request validation | `backend-stack.ts`: `validateRequestBody: true, validateRequestParameters: true` | T3 |
| CloudWatch logging for all Lambdas | `backend-stack.ts`: Explicit LogGroup per function, retention ONE_WEEK | T14 |
| API Gateway access logging | `backend-stack.ts`: `accessLogFormat: jsonWithStandardFields()` | T14 |
| X-Ray tracing enabled | `backend-stack.ts`: `tracingEnabled: true` | T14 |
| Lambda timeout limits | `backend-stack.ts`: 30-60s per function | T8 |
| Image auto-downscaling | `agents.py`: Pages over ~3.8MB downscaled before model invocation | T8 |

### Code Security

| Control | Evidence | Threats Mitigated |
|---------|----------|-------------------|
| ASH SAST scan (bandit) passed | `guidance-docs/ash-results/`: 0 code vulnerabilities | T10 |
| ASH semgrep scan passed | `guidance-docs/ash-results/`: 0 findings | T10 |
| ASH IaC scan (checkov) passed | `guidance-docs/ash-results/`: 0 infrastructure misconfigurations | T5, T12 |
| npm audit fix applied | Frontend dependencies updated, 0 vulnerabilities remaining | T10 |
| Input validation in Lambda | `lambdas/blueprint-api/index.py`: validates user ownership, checks required fields | T2, T3 |

### AI/ML Security

| Control | Evidence | Threats Mitigated |
|---------|----------|-------------------|
| One agent session per page | `agents.py`: Fresh Opus session per page prevents context contamination | T4 |
| Structured output via tool calls | `tools/structured_tools.py`: Schema-enforced parameters, not free-form text | T7 |
| Self-healing audit pipeline | `pipeline.py`: Auditor validates summary, Remediator corrects if issues found | T7 |
| Dual-format persistence (JSON + MD) | `tools/structured_tools.py`: Both formats saved for verification | T14 |
| Idempotent pipeline stages | `agents.py`: Checks for existing output before processing | T8 |

---

## 4. Did we do a good enough job (for now)?

### Review & Validation

- All infrastructure code scanned with ASH (bandit, semgrep, checkov, detect-secrets, npm-audit)
- All fixable npm dependency vulnerabilities resolved
- CDK code follows AWS security best practices (BlockPublicAccess, encryption, least-privilege)
- Authentication enforced on all endpoints (no unauthenticated access)
- This Guidance is a reference implementation intended for evaluation and customization, not direct production deployment without additional hardening

### ASH Findings Status

| Scanner | Status | Findings |
|---------|--------|----------|
| bandit (Python SAST) | PASSED | 0 |
| semgrep (code patterns) | PASSED | 0 |
| checkov (IaC security) | PASSED | 0 |
| detect-secrets | PASSED | 0 |
| npm-audit (dependencies) | PASSED | 0 (after fix) |
| npm-audit (CDK bundled) | KNOWN ISSUE | 2 findings in aws-cdk-lib transitive deps (brace-expansion, fast-uri) — cannot be independently updated |

### Known Limitations and Residual Risks

| # | Limitation | Risk | Recommendation for Production |
|---|-----------|------|-------------------------------|
| L1 | DynamoDB tables use `removalPolicy: DESTROY` | Data loss on stack deletion | Change to `RETAIN` for production |
| L2 | No VPC isolation (PUBLIC network mode) | AgentCore Runtime accessible over public internet | Deploy with `network_mode: VPC` and VPC endpoints |
| L3 | Single-region deployment | No disaster recovery | Deploy to multiple regions with cross-region replication |
| L4 | S3 CORS allows all origins (`*`) for presigned URLs | Broader access than necessary | Restrict to specific frontend domain |
| L5 | No Amazon Bedrock Guardrails configured | No content filtering on model inputs/outputs | Add Guardrails for content moderation in production |
| L6 | CloudWatch log retention set to ONE_WEEK | Limited forensic investigation window | Increase to 90+ days for production |
| L7 | No WAF on API Gateway | No protection against common web exploits | Add AWS WAF with managed rule groups |
| L8 | No AWS Config or SecurityHub integration | No continuous compliance monitoring | Enable Config rules and SecurityHub standards |
| L9 | Blueprint bucket RETAIN policy means manual cleanup | Orphaned data if stack is recreated | Implement lifecycle policies or automated cleanup |
| L10 | No rate limiting per user (only global API throttle) | Single user could consume all capacity | Implement per-user usage plans in API Gateway |
| L11 | 2 CDK-bundled dependency vulnerabilities | brace-expansion (moderate), fast-uri (high) in aws-cdk-lib | Update aws-cdk-lib when patched version available |
| L12 | No encryption key rotation (uses S3-managed keys) | Keys managed by AWS, no customer control | Use KMS CMK with automatic rotation for sensitive data |
| L13 | Agent memory has 30-day expiry only | No long-term audit of agent interactions | Implement separate audit logging for compliance |
| L14 | No input size validation on PDF upload | Very large PDFs could cause timeout/cost issues | Add file size limit check in upload Lambda |

### Conclusion

Given that this is a reference implementation (AWS Guidance) intended to demonstrate AI-powered blueprint analysis patterns, the security controls in place are appropriate. The architecture follows AWS security best practices for authentication, authorization, encryption, and least-privilege access. All code-level vulnerabilities have been addressed (ASH scans pass clean), and the known limitations are documented with clear production recommendations.

Customers deploying this Guidance should review the limitations above and implement the recommended hardening measures based on their specific security requirements and compliance needs.

---

*This threat model was generated on 2026-05-20 based on codebase analysis and ASH security scan results.*
